﻿
    function ConfirmDelete() {

        var count = document.getElementById("<%=hfCount.ClientID %>").value;
        var gv = document.getElementById("<%=gvAll.ClientID%>");
        var chk = gv.getElementsByTagName("input");

        for (var i = 0; i < chk.length; i++) {
            if (chk[i].checked && chk[i].id.indexOf("chkAll") == -1) {
                count++;
            }
        }

        if (count == 0) {
            alert("No records to delete.");
            return false;
        }

        else {
            return confirm("Do you want to delete " + count + " records.");
        }
    }
