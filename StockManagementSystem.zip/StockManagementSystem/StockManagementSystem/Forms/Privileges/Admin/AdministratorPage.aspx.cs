﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;

namespace StockManagementSystem.Forms.Privileges.Admin
{
    public partial class AdministratorPage : System.Web.UI.Page
    {
        private SqlConnection connectSql;
        private SqlCommand displayProfileCmd;
        private SqlCommand createProfileCmd;
        private SqlCommand checkAccountNameCmd;
        private SqlCommand checkAccountNameUpdateCmd;
        private SqlCommand updateProfileWithoutPasswordCmd;
        private SqlCommand updateProfileCmd;
        private SqlCommand deleteProfileCmd;

        private SqlDataAdapter adapter;
        private DataSet dataSet;
        private string dataKey = "Check";
        private DataTable dataTable;

        private int selectedUserId;
        private string userPrivileges;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user_name"] != null && Session["password"] != null)
            {
                Response.ClearHeaders();
                Response.AddHeader("Cache-Control", "no-cache, no-store, max-age=0, must-revalidate");
                Response.AddHeader("Pragma", "no-cache");

                //Handle privileges who can access this page
                if ((string)Session["privilege"] != "Owner" && (string)Session["privilege"] != "Admin")
                {
                    Response.Write("<script>window.alert('Access Denied!')</script>");
                    Response.Redirect("~/Forms/DashboardUser.aspx");
                }

                string connectStr = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|AccountDatabase.mdf";
                connectSql = new SqlConnection(connectStr);

                try
                {
                    connectSql.Open();
                }
                catch (SqlException ex)
                {
                    Response.Write("<script>window.alert('SQL connection Failed!')</script>");
                }

                string checkAccountNameStr = "SELECT Name FROM UserAccounts WHERE Name = @user_name_exist";
                checkAccountNameCmd = new SqlCommand(checkAccountNameStr, connectSql);

                string checkAccountNameUpdateStr = "SELECT Id,Name FROM UserAccounts WHERE Name = @user_name_exist AND NOT Id = @user_id";
                checkAccountNameUpdateCmd = new SqlCommand(checkAccountNameUpdateStr, connectSql);

                string createProfileStr = "INSERT INTO UserAccounts(Name, Password, Email, Privileges, ProfileImage) " +
                "VALUES(@user_name, @password, @email, @privileges, @profile_image)";
                createProfileCmd = new SqlCommand(createProfileStr, connectSql);

                string updateProfileWithoutPasswordStr = "UPDATE UserAccounts SET Name = @user_name, Email = @user_email, " +
                "ProfileImage = @user_image WHERE Id = @user_id";
                updateProfileWithoutPasswordCmd = new SqlCommand(updateProfileWithoutPasswordStr, connectSql);

                string updateProfileStr = "UPDATE UserAccounts SET Name = @user_name, Password = @user_password, " +
                "Email = @user_email, ProfileImage = @user_image WHERE Id = @user_id";
                updateProfileCmd = new SqlCommand(updateProfileStr, connectSql);

                string deleteProfileStr = "DELETE FROM UserAccounts WHERE Id = @user_id";
                deleteProfileCmd = new SqlCommand(deleteProfileStr, connectSql);
            }
            else
            {
                Response.Write("<script>window.alert('Login Failed!')</script>");
                Response.Redirect("~/Forms/Login.aspx");
            }
        }

        protected void onRowDataBound(object sender, System.Web.UI.WebControls.GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes["onclick"] = Page.ClientScript.GetPostBackClientHyperlink(gridViewProfile, "Select$" + e.Row.RowIndex);
                e.Row.Attributes["style"] = "cursor:pointer";
            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedUserId = int.Parse(gridViewProfile.SelectedRow.Cells[0].Text);
            loadDatabase();

            if (userPrivileges == "User") {
                txtUserNameProfile.Enabled = true;
                txtPassword.Enabled = true;
                txtConfirmPassword.Enabled = true;
                txtEmailProfile.Enabled = true;
                fileUploadImage.Enabled = true;

                btnCreate.Enabled = false;
                btnUpdate.Enabled = true;
                btnDelete.Enabled = true;
            }
            else
            {
                txtUserNameProfile.Enabled = false;
                txtPassword.Enabled = false;
                txtConfirmPassword.Enabled = false;
                txtEmailProfile.Enabled = false;
                fileUploadImage.Enabled = false;

                btnCreate.Enabled = false;
                btnUpdate.Enabled = false;
                btnDelete.Enabled = false;
            }
        }

        protected void btnNewAccount_Click(object sender, EventArgs e)
        {
            txtUserId.Text = "This will Generate Automatically";
            txtUserNameProfile.Text = "";
            txtPassword.Text = "";
            txtConfirmPassword.Text = "";
            txtEmailProfile.Text = "";
            imgProfile.ImageUrl = "~/Images/ProfileImages/" + "profile_image_original.png";

            txtUserNameProfile.Enabled = true;
            txtPassword.Enabled = true;
            txtConfirmPassword.Enabled = true;
            txtEmailProfile.Enabled = true;
            fileUploadImage.Enabled = true;

            btnCreate.Enabled = true;
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;
        }

        protected void btnCreate_Click(object sender, EventArgs e)
        {
            string user_name = txtUserNameProfile.Text;
            string user_password = txtPassword.Text;
            string confirm_password = txtConfirmPassword.Text;
            string user_email = txtEmailProfile.Text;
            string profile_image;
            string dataKey = "Check";

            if (user_name == "" || user_password == "")
            {
                Response.Write("<script>window.alert('Please Enter Username and Password.')</script>");
                return;
            }

            checkAccountNameCmd.Parameters.Clear();
            checkAccountNameCmd.Parameters.AddWithValue("user_name_exist", user_name);

            SqlDataAdapter adapter = new SqlDataAdapter(checkAccountNameCmd);
            DataSet dataSet = new DataSet();
            adapter.Fill(dataSet, dataKey);

            DataTable dataTable = dataSet.Tables[dataKey];

            if (dataTable.Rows.Count == 0)
            {
                if (user_password != confirm_password)
                {
                    Response.Write("<script>window.alert('Confirm password not matched!')</script>");
                    txtPassword.Text = "";
                    txtConfirmPassword.Text = "";
                    return;
                }

                createProfileCmd.Parameters.Clear();
                createProfileCmd.Parameters.AddWithValue("user_name", user_name);
                createProfileCmd.Parameters.AddWithValue("password", user_password);
                createProfileCmd.Parameters.AddWithValue("email", user_email);
                createProfileCmd.Parameters.AddWithValue("privileges", "User");

                string profile_image_filename;
                string profile_image_path;

                if (fileUploadImage.HasFile)
                {
                    profile_image_filename = fileUploadImage.FileName;
                    fileUploadImage.SaveAs(MapPath("~/Images/ProfileImages/" + fileUploadImage.FileName));
                    profile_image_path = "~/Images/ProfileImages/" + profile_image_filename;
                }
                else
                {
                    profile_image_path = imgProfile.ImageUrl;
                }

                createProfileCmd.Parameters.AddWithValue("profile_image", profile_image_path);

                int rowsAffected = createProfileCmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    Response.Write("<script>window.alert('Create Account Successful!')</script>");
                    Response.Redirect(Request.RawUrl);
                }
                else
                {
                    Response.Write("<script>window.alert('Create Account Failed!')</script>");
                }

            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {

            string user_name = txtUserNameProfile.Text;
            string user_new_password = txtPassword.Text;
            string user_confirm_password = txtConfirmPassword.Text;
            string user_email = txtEmailProfile.Text;

            string profile_image_filename;
            string profile_image_path;

            checkAccountNameUpdateCmd.Parameters.Clear();
            checkAccountNameUpdateCmd.Parameters.AddWithValue("user_name_exist", user_name);
            checkAccountNameUpdateCmd.Parameters.AddWithValue("user_id", txtUserId.Text);

            SqlDataAdapter adapterCheck = new SqlDataAdapter(checkAccountNameUpdateCmd);
            DataSet dataSetCheck = new DataSet();
            adapterCheck.Fill(dataSetCheck, dataKey);

            DataTable dataTableCheck = dataSetCheck.Tables[dataKey];

            if (dataTableCheck.Rows.Count == 0)
            {

                if (txtPassword.Text == "" && txtConfirmPassword.Text == "")
                {
                    updateProfileWithoutPasswordCmd.Parameters.Clear();
                    updateProfileWithoutPasswordCmd.Parameters.AddWithValue("user_id", txtUserId.Text);
                    updateProfileWithoutPasswordCmd.Parameters.AddWithValue("user_name", user_name);
                    updateProfileWithoutPasswordCmd.Parameters.AddWithValue("user_email", user_email);

                    if (fileUploadImage.HasFile)
                    {
                        profile_image_filename = fileUploadImage.FileName;
                        fileUploadImage.SaveAs(MapPath("~/Images/ProfileImages/" + fileUploadImage.FileName));
                        profile_image_path = "~/Images/ProfileImages/" + profile_image_filename;
                    }
                    else
                    {
                        profile_image_path = imgProfile.ImageUrl;
                    }

                    updateProfileWithoutPasswordCmd.Parameters.AddWithValue("user_image", profile_image_path);

                    int rowsAffected = updateProfileWithoutPasswordCmd.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        Response.Write("<script>window.alert('Update Successful!')</script>");
                        Response.Redirect(Request.RawUrl);
                    }
                    else
                    {
                        Response.Write("<script>window.alert('Update Failed!')</script>");
                    }
                }
                else
                {
                    //DataRow dataRow = dataTable.Rows[0];
                    if (user_new_password == user_confirm_password)
                    {
                        updateProfileCmd.Parameters.Clear();
                        updateProfileCmd.Parameters.AddWithValue("user_id", txtUserId.Text);
                        updateProfileCmd.Parameters.AddWithValue("user_name", user_name);
                        updateProfileCmd.Parameters.AddWithValue("user_password", user_new_password);
                        updateProfileCmd.Parameters.AddWithValue("user_email", user_email);

                        if (fileUploadImage.HasFile)
                        {
                            profile_image_filename = fileUploadImage.FileName;
                            fileUploadImage.SaveAs(MapPath("~/Images/ProfileImages/" + fileUploadImage.FileName));
                            profile_image_path = "~/Images/ProfileImages/" + profile_image_filename;
                        }
                        else
                        {
                            profile_image_path = imgProfile.ImageUrl;
                        }

                        updateProfileCmd.Parameters.AddWithValue("user_image", profile_image_path);

                        int rowsAffected = updateProfileCmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            Response.Write("<script>window.alert('Update Successful!')</script>");
                            Response.Redirect(Request.RawUrl);
                        }
                        else
                        {
                            Response.Write("<script>window.alert('Update Failed!')</script>");
                        }
                    }
                    else
                    {
                        Response.Write("<script>window.alert('Confirm Password not matched!')</script>");
                        txtPassword.Text = "";
                        txtConfirmPassword.Text = "";
                    }
                }
            }
            else
            {
                Response.Write("<script>window.alert('Username existed!')</script>");
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            if (txtUserId.Text == "" || txtUserId.Text == "The User Id will Generate Automatically")
            {
                return;
            }
            if (txtUserId.Text == Session["user_id"].ToString())
            {
                Response.Write("<script>window.alert('You are not allow to delete your account. Asking Owner to delete your account.')</script>");
                return;
            }
            if (int.Parse(txtUserId.Text) > 0) {
                deleteProfileCmd.Parameters.Clear();
                deleteProfileCmd.Parameters.AddWithValue("user_id", txtUserId.Text);

                int rowsAffected = deleteProfileCmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    Response.Write("<script>window.alert('Delete Successful!')</script>");
                }
                Response.Redirect(Request.RawUrl);
            }
        }

        private void loadDatabase()
        {
            string displayProfileStr = "SELECT * FROM UserAccounts WHERE Id = @user_id";
            displayProfileCmd = new SqlCommand(displayProfileStr, connectSql);

            displayProfileCmd.Parameters.Clear();
            displayProfileCmd.Parameters.AddWithValue("user_id", selectedUserId);

            adapter = new SqlDataAdapter(displayProfileCmd);
            dataSet = new DataSet();
            adapter.Fill(dataSet, dataKey);

            dataTable = dataSet.Tables[dataKey];

            if (dataTable.Rows.Count == 0)
            {
                //Do Nothing
            }
            else
            {
                DataRow dataRow = dataTable.Rows[0];
                txtUserId.Text = dataRow["Id"].ToString();
                txtUserNameProfile.Text = dataRow["Name"].ToString();
                txtEmailProfile.Text = dataRow["Email"].ToString();
                userPrivileges = dataRow["Privileges"].ToString();

                if (dataRow["ProfileImage"].ToString() != null)
                {
                    imgProfile.ImageUrl = dataRow["ProfileImage"].ToString();
                }
            }
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            connectSql.Close();
            Response.Redirect("~/Forms/Dashboard" + Session["privilege"] + ".aspx");
        }

        protected void btnDisplay_Click(object sender, EventArgs e)
        {
            if (fileUploadImage.HasFile)
            {
                fileUploadImage.SaveAs(MapPath("~/Images/ProfileImages/" + fileUploadImage.FileName));
                imgProfile.ImageUrl = "~/Images/ProfileImages/" + fileUploadImage.FileName;
            }
        }

        protected void linkLogout_Click(object sender, EventArgs e)
        {
            connectSql.Close();
            Session.Remove("user_name");
            Session.Remove("password");
            Session.Remove("privilege");
            Session.RemoveAll();
            Response.Redirect(Request.RawUrl);
        }

        protected void linkBack_Click(object sender, EventArgs e)
        {
            connectSql.Close();
            Response.Redirect("~/Forms/Dashboard" + Session["privilege"].ToString() + ".aspx");
        }
    }
}