﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;

namespace StockManagementSystem.Forms.Privileges.Users
{
    public partial class StockDetailsPage : System.Web.UI.Page
    {
        private SqlConnection connectSql;
        private SqlCommand searchStockCmd;
        private SqlCommand updateStockCmd;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user_name"] != null && Session["password"] != null)
            {
                //Response.Write("<script>window.alert('Login Sucessful!')</script>"); testing line
                Response.ClearHeaders();
                Response.AddHeader("Cache-Control", "no-cache, no-store, max-age=0, must-revalidate");
                Response.AddHeader("Pragma", "no-cache");

                //Remove Administrator linkbutton if privilege is not Owner and Admin
                if ((string)Session["privilege"] != "Owner" && (string)Session["privilege"] != "Admin")
                {
                    linkAdminPage.Visible = false;
                }
            }
            else
            {
                Response.Write("<script>window.alert('Login Failed!')</script>");
                Response.Redirect("~/Forms/Login.aspx");
            }

            string connectStr = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|StockDatabase.mdf";
            connectSql = new SqlConnection(connectStr);

            try
            {
                connectSql.Open();
            }
            catch (SqlException ex)
            {
                Response.Write("<script>window.alert('SQL connection Failed!')</script>");
            }

            loadDatabase();
        }

        private void loadDatabase()
        {
            string searchStockStr = "SELECT * FROM Stocks WHERE StockId = @stock_id";
            searchStockCmd = new SqlCommand(searchStockStr, connectSql);

            string updateStockStr = "UPDATE Stocks SET StockName = @stock_name, Category = @stock_category, " +
                "Brand = @stock_brand, Price = @stock_price, StockStatus = @stock_status, Quantity = @stock_quantity, " +
                "Image = @stock_image WHERE StockId = @stock_id";
            updateStockCmd = new SqlCommand(updateStockStr, connectSql);

            string dataKey = "Check";
            searchStockCmd.Parameters.Clear();
            searchStockCmd.Parameters.AddWithValue("stock_id", int.Parse((string)Session["stock_id"]));

            SqlDataAdapter adapter = new SqlDataAdapter(searchStockCmd);
            DataSet dataSet = new DataSet();
            adapter.Fill(dataSet, dataKey);

            DataTable dataTable = dataSet.Tables[dataKey];

            if (dataTable.Rows.Count == 0)
            {
                return;
            }
            else
            {
                if (!IsPostBack) {
                    DataRow dataRow = dataTable.Rows[0];
                    txtStockName.Text = (string)dataRow["StockName"];
                    txtCategory.Text = (string)dataRow["Category"];
                    txtBrand.Text = (string)dataRow["Brand"];
                    txtPrice.Text = dataRow["Price"].ToString();
                    ddlStockStatus.Text = (string)dataRow["StockStatus"];
                    txtQuantity.Text = dataRow["Quantity"].ToString();

                    if (dataRow["Image"].ToString() != null)
                    {
                        imgStock.ImageUrl = dataRow["Image"].ToString();
                    }

                    if (DBNull.Value.Equals(dataRow["Model3D"]))
                    {
                        displayModel.Enabled = false;
                    }
                    if (DBNull.Value.Equals(dataRow["Texture"]))
                    {
                        displayModel.Enabled = false;
                    }
                }
            }
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            //Bugs:
            //System.InvalidOperationException: 'Timeout expired.  
            //The timeout period elapsed prior to obtaining a connection from the pool.  
            //This may have occurred because all pooled connections were in use and max pool size was reached.'
            connectSql.Close();
            Response.Redirect("~/Forms/Privileges/Users/StockListPage.aspx");
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            string stock_name = txtStockName.Text;
            string stock_category = txtCategory.Text;
            string stock_brand = txtBrand.Text;
            float stock_price;
            string stock_status = ddlStockStatus.Text;
            int stock_quantity;
            string stock_image;

            if (stock_name == "" || stock_category == "" || stock_brand == "" || stock_status == "")
            {
                Response.Write("<script>window.alert('Please Fill All the Form.')</script>");
                return;
            }

            try
            {
                stock_price = float.Parse(txtPrice.Text);
                stock_quantity = int.Parse(txtQuantity.Text);
            }
            catch (FormatException ex)
            {
                Response.Write("<script>window.alert('Please enter a valid numbers in Price and Quantity Field!')</script>");
                txtPrice.Text = "";
                txtQuantity.Text = "";
                return;
            }

            if (stock_price < 0 || stock_quantity < 0)
            {
                Response.Write("<script>window.alert('Negative value in Price and Quantity Field is not allow!')</script>");
                return;
            }

            updateStockCmd.Parameters.Clear();
            updateStockCmd.Parameters.AddWithValue("stock_id", int.Parse((string)Session["stock_id"]));
            updateStockCmd.Parameters.AddWithValue("stock_name", stock_name);
            updateStockCmd.Parameters.AddWithValue("stock_category", stock_category);
            updateStockCmd.Parameters.AddWithValue("stock_brand", stock_brand);
            updateStockCmd.Parameters.AddWithValue("stock_price", stock_price);
            updateStockCmd.Parameters.AddWithValue("stock_status", stock_status);
            updateStockCmd.Parameters.AddWithValue("stock_quantity", stock_quantity);

            string stock_image_filename;
            string stock_image_path;

            if (fileUploadImage.HasFile)
            {
                stock_image_filename = fileUploadImage.FileName;
                fileUploadImage.SaveAs(MapPath("~/Images/StockImages/" + fileUploadImage.FileName));
                stock_image_path = "~/Images/StockImages/" + stock_image_filename;
            }
            else
            {
                stock_image_path = imgStock.ImageUrl;
            }

            updateStockCmd.Parameters.AddWithValue("stock_image", stock_image_path);

            int rowsAffected = updateStockCmd.ExecuteNonQuery();
            if (rowsAffected > 0)
            {
                //Response.Redirect(Request.RawUrl);
                connectSql.Close();
                Response.Redirect("~/Forms/Privileges/Users/StockListPage.aspx");
            }
        }

        protected void linkAdminPage_Click(object sender, EventArgs e)
        {
            connectSql.Close();
            Response.Redirect("~/Forms/Privileges/" + Session["privilege"].ToString() + "/AdministratorPage.aspx");
        }

        protected void linkLogout_Click(object sender, EventArgs e)
        {
            connectSql.Close();
            Session.Remove("user_name");
            Session.Remove("password");
            Session.Remove("privilege");
            Session.RemoveAll();
            Response.Redirect(Request.RawUrl);
        }

        protected void linkBack_Click(object sender, EventArgs e)
        {
            connectSql.Close();
            Response.Redirect("~/Forms/Dashboard" + Session["privilege"].ToString() + ".aspx");
        }

        protected void txtQuantity_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (int.Parse(txtQuantity.Text) <= 0)
                {
                    ddlStockStatus.SelectedIndex = 2;
                }
                if (int.Parse(txtQuantity.Text) < 20 && int.Parse(txtQuantity.Text) > 0)
                {
                    ddlStockStatus.SelectedIndex = 1;
                }
                if (int.Parse(txtQuantity.Text) >= 20)
                {
                    ddlStockStatus.SelectedIndex = 0;
                }
            }
            catch (FormatException ex)
            {
                return;
            }
        }

        protected void displayModel_Click(object sender, EventArgs e)
        {
            connectSql.Close();
            Response.Redirect("~/Forms/Privileges/Users/3DRendererPage.aspx");
        }
    }
}