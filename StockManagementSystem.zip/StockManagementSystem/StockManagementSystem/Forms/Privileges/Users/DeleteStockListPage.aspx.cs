﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;
using System.Collections;

using System.Text;

namespace StockManagementSystem.Forms.Privileges.Users
{
    public partial class DeleteStockListPage : System.Web.UI.Page
    {
        private SqlConnection connectSql;
        private SqlCommand stockListCmd;
        private SqlCommand deleteStocksCmd;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user_name"] != null && Session["password"] != null)
            {
                //Response.Write("<script>window.alert('Login Sucessful!')</script>"); testing line
                Response.ClearHeaders();
                Response.AddHeader("Cache-Control", "no-cache, no-store, max-age=0, must-revalidate");
                Response.AddHeader("Pragma", "no-cache");

                //Remove Administrator linkbutton if privilege is not Owner and Admin
                if ((string)Session["privilege"] != "Owner" && (string)Session["privilege"] != "Admin")
                {
                    linkAdminPage.Visible = false;
                }
            }
            else
            {
                Response.Write("<script>window.alert('Login Failed!')</script>");
                Response.Redirect("~/Forms/Login.aspx");
            }

            //gridViewStocks.AllowPaging = true;
            loadData();
            if (IsPostBack)
            {
                if (gridViewStocks.Rows.Count > 0) {
                    getSelectedData();
                }
            }
        }

        protected void onRowDataBound(object sender, System.Web.UI.WebControls.GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //e.Row.Attributes.Add("onmouseover", "mouseEvents(this, event)");
                //e.Row.Attributes.Add("onmouseout", "mouseEvents(this, event)");
                e.Row.Attributes["onclick"] = Page.ClientScript.GetPostBackClientHyperlink(gridViewStocks, "Select$" + e.Row.RowIndex);
                e.Row.Attributes["style"] = "cursor:pointer";
            }
            if (e.Row.RowType == DataControlRowType.Header)
            {
                e.Row.Attributes["onclick"] = Page.ClientScript.GetPostBackClientHyperlink(gridViewStocks, "Select$" + e.Row.RowIndex);
                e.Row.Attributes["style"] = "cursor:pointer";
            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            foreach (GridViewRow row in gridViewStocks.Rows)
            {
                CheckBox chkSelect = row.Cells[7].FindControl("chkSelect") as CheckBox;
                if (chkSelect.Checked)
                {
                    btnDeleteStock.Enabled = true;
                    return;
                }
                else
                {
                    btnDeleteStock.Enabled = false;
                }
            }
        }

        protected void onPaging(object sender, GridViewPageEventArgs e)
        {
            gridViewStocks.PageIndex = e.NewPageIndex;
            gridViewStocks.DataBind();
            setSelectedData();
        }

        protected void btnDeleteStock_Click(object sender, EventArgs e)
        {
            int count = 0;
            setSelectedData();
            gridViewStocks.DataBind();

            ArrayList arrSelectedList = (ArrayList)ViewState["SelectedList"];
            count = arrSelectedList.Count;

            for (int i=0; i<gridViewStocks.Rows.Count;i++)
            {
                if (arrSelectedList.Contains(gridViewStocks.DataKeys[i].Value))
                {

                    deleteRecord(gridViewStocks.DataKeys[i].Value.ToString());
                    arrSelectedList.Remove(gridViewStocks.DataKeys[i].Value);
                }
            }
            ViewState["SelectedList"] = arrSelectedList;
            hfCount.Value = "0";

            Response.Redirect(Request.RawUrl);
        }


        protected void btnCancel_Click(object sender, EventArgs e)
        {
            connectSql.Close();
            Response.Redirect("~/Forms/Privileges/Users/StockListPage.aspx");
        }

        private void loadData()
        {
            string connectStr = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|StockDatabase.mdf";
            connectSql = new SqlConnection(connectStr);

            try
            {
                connectSql.Open();
            }
            catch (SqlException ex)
            {
                Response.Write("<script>window.alert('SQL connection Failed!')</script>");
            }

            string stockListStr = "SELECT * FROM Stocks";
            stockListCmd = new SqlCommand(stockListStr, connectSql);

            string deleteStocksStr = "DELETE FROM Stocks WHERE StockId = @stock_id";
            deleteStocksCmd = new SqlCommand(deleteStocksStr, connectSql);

            SqlDataAdapter adapter = new SqlDataAdapter(stockListCmd);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);
        }

        public void getSelectedData()
        {
            ArrayList arrSelectedList;
            if (ViewState["SelectedList"] != null)
            {
                arrSelectedList = (ArrayList)ViewState["SelectedList"];
            }
            else
            {
                arrSelectedList = new ArrayList();
            }
            CheckBox chkAll = (CheckBox)gridViewStocks.HeaderRow.Cells[0].FindControl("chkAll"); //System.NullReferenceException

            for (int i = 0;i < gridViewStocks.Rows.Count;i++)
            {
                if (chkAll.Checked)
                {
                    if (!arrSelectedList.Contains(gridViewStocks.DataKeys[i].Value))
                    {
                        arrSelectedList.Add(gridViewStocks.DataKeys[i].Value);
                    }
                }
                else
                {
                    CheckBox chkSelect = (CheckBox)gridViewStocks.Rows[i].Cells[0].FindControl("chkSelect");

                    if (chkSelect.Checked)
                    {
                        if (!arrSelectedList.Contains(gridViewStocks.DataKeys[i].Value))
                        {
                            arrSelectedList.Add(gridViewStocks.DataKeys[i].Value);
                        }
                    }
                    else
                    {
                        if (arrSelectedList.Contains(gridViewStocks.DataKeys[i].Value))
                        {
                            arrSelectedList.Remove(gridViewStocks.DataKeys[i].Value);
                        }
                    }
                }
            }
            ViewState["SelectedList"] = arrSelectedList;
        }

        private void setSelectedData()
        {
            int currentCount = 0;
            CheckBox chkAll = (CheckBox)gridViewStocks.HeaderRow.Cells[0].FindControl("chkAll");

            chkAll.Checked = true;
            ArrayList arrSelectedList = (ArrayList)ViewState["SelectedList"];

            for (int i = 0;i < gridViewStocks.Rows.Count; i++)
            {
                CheckBox chkSelect = (CheckBox)gridViewStocks.Rows[i].Cells[0].FindControl("chkSelect");

                if (chkSelect != null)
                {
                    chkSelect.Checked = arrSelectedList.Contains(gridViewStocks.DataKeys[i].Value);
                    if (!chkSelect.Checked)
                    {
                        chkAll.Checked = false;
                    }
                    else
                    {
                        currentCount++;
                    }
                }
            }
            hfCount.Value = (arrSelectedList.Count - currentCount).ToString();
        }

        private void deleteRecord(string stock_id)
        {
            deleteStocksCmd.Parameters.Clear();
            deleteStocksCmd.Parameters.AddWithValue("stock_id", stock_id);
            deleteStocksCmd.ExecuteNonQuery();
        }

        protected void linkBack_Click(object sender, EventArgs e)
        {
            connectSql.Close();
            Response.Redirect("~/Forms/Dashboard" + Session["privilege"].ToString() + ".aspx");
        }

        protected void linkAdminPage_Click(object sender, EventArgs e)
        {
            connectSql.Close();
            Response.Redirect("~/Forms/Privileges/" + Session["privilege"].ToString() + "/AdministratorPage.aspx");
        }

        protected void linkLogout_Click(object sender, EventArgs e)
        {
            connectSql.Close();
            Session.Remove("user_name");
            Session.Remove("password");
            Session.Remove("privilege");
            Session.RemoveAll();
            Response.Redirect(Request.RawUrl);
        }
    }
}