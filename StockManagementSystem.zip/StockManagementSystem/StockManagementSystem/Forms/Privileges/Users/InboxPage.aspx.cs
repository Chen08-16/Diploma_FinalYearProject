﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;

namespace StockManagementSystem.Forms.Privileges.Users
{
    public partial class InboxPage : System.Web.UI.Page
    {
        private SqlConnection connectSql;
        private SqlCommand checkRunningLowCmd;
        private SqlCommand checkOutOfStockCmd;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user_name"] != null && Session["password"] != null)
            {
                //Response.Write("<script>window.alert('Login Sucessful!')</script>"); testing line
                Response.ClearHeaders();
                Response.AddHeader("Cache-Control", "no-cache, no-store, max-age=0, must-revalidate");
                Response.AddHeader("Pragma", "no-cache");

                //Remove Administrator linkbutton if privilege is not Owner and Admin
                if ((string)Session["privilege"] != "Owner" && (string)Session["privilege"] != "Admin")
                {
                    linkAdminPage.Visible = false;
                }

                string connectStr = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|StockDatabase.mdf";
                connectSql = new SqlConnection(connectStr);

                try
                {
                    connectSql.Open();
                }
                catch (SqlException ex)
                {
                    Response.Write("<script>window.alert('SQL connection Failed!')</script>");
                }

                loadDatabase();
            }
            else
            {
                Response.Write("<script>window.alert('Login Failed!')</script>");
                Response.Redirect("~/Forms/Login.aspx");
            }

            //Remove Administrator linkbutton if privilege is not Owner and Admin
            if ((string)Session["privilege"] != "Owner" && (string)Session["privilege"] != "Admin")
            {
                linkAdminPage.Visible = false;
            }
            connectSql.Close();
        }

        private void loadDatabase()
        {
            string checkRunningLowStr = "SELECT StockName FROM Stocks WHERE Quantity < 20 AND Quantity > 0 OR StockStatus = 'Running Low'";
            checkRunningLowCmd = new SqlCommand(checkRunningLowStr, connectSql);

            string checkOutOfStockStr = "SELECT StockName FROM Stocks WHERE Quantity = 0 OR StockStatus = 'Out of Stock'";
            checkOutOfStockCmd = new SqlCommand(checkOutOfStockStr, connectSql);

            string dataKey = "key";
            string dataKey2 = "key2";
            int count = 0;

            SqlDataAdapter adapter = new SqlDataAdapter(checkOutOfStockCmd);
            DataSet dataSet = new DataSet();
            adapter.Fill(dataSet, dataKey);

            DataTable dataTableDataSource = dataSet.Tables[dataKey];

            count = insertIntoGridView(dataTableDataSource, "", "", 0);

            adapter = new SqlDataAdapter(checkRunningLowCmd);
            adapter.Fill(dataSet, dataKey2);

            DataTable dataTableDataSource2 = new DataTable();
            dataTableDataSource2 = dataTableDataSource;
            dataTableDataSource2.Merge(dataSet.Tables[dataKey2]);

            insertIntoGridView(dataTableDataSource2, " is running low.", " was out of stock!", count);
        }

        private int insertIntoGridView(DataTable dt, string text, string text2, int count)
        {
            gridViewInbox.DataSource = dt;
            gridViewInbox.DataBind();

            //gridViewInbox.HeaderRow.Cells[0].Visible = false;
            gridViewInbox.HeaderRow.Cells[0].Text = "";

            for (int i = 0; i < count; i++)
            {
                gridViewInbox.Rows[i].Cells[0].Text = gridViewInbox.Rows[i].Cells[0].Text + text2;
            }

            for (int i = count; i < gridViewInbox.Rows.Count; i++)
            {
                gridViewInbox.Rows[i].Cells[0].Text = gridViewInbox.Rows[i].Cells[0].Text + text;
                count = count + 1;
            }

            return count;
        }

        protected void linkBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Forms/Dashboard" + Session["privilege"].ToString() + ".aspx");
        }

        protected void linkAdminPage_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Forms/Privileges/" + Session["privilege"].ToString() + "/AdministratorPage.aspx");
        }

        protected void linkLogout_Click(object sender, EventArgs e)
        {
            Session.Remove("user_name");
            Session.Remove("password");
            Session.Remove("privilege");
            Session.RemoveAll();
            Response.Redirect(Request.RawUrl);
        }
    }
}