﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;

namespace StockManagementSystem.Forms.Privileges.Users
{
    public partial class AddStockPage : System.Web.UI.Page
    {
        private SqlConnection connectSql;
        private SqlCommand addStockCmd;
        private SqlCommand addStockWith3DModelCmd;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user_name"] != null && Session["password"] != null)
            {
                Response.ClearHeaders();
                Response.AddHeader("Cache-Control", "no-cache, no-store, max-age=0, must-revalidate");
                Response.AddHeader("Pragma", "no-cache");

                //Remove Administrator linkbutton if privilege is not Owner and Admin
                if ((string)Session["privilege"] != "Owner" && (string)Session["privilege"] != "Admin")
                {
                    linkAdminPage.Visible = false;
                }
            }
            else
            {
                Response.Write("<script>window.alert('Login Failed!')</script>");
                Response.Redirect("~/Forms/Login.aspx");
            }

            string connectStr = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|StockDatabase.mdf";
            connectSql = new SqlConnection(connectStr);

            try
            {
                connectSql.Open();
            }
            catch (SqlException ex)
            {
                Response.Write("<script>window.alert('SQL connection Failed!')</script>");
            }

            string addStockStr = "INSERT INTO Stocks(" +
                "StockName, Category, Brand, Price, StockStatus, Quantity, Image" +
                ") VALUES(" +
                "@stock_name, @stock_category, @stock_brand, @stock_price, @stock_status, @stock_quantity, @stock_image" +
                ")";
            addStockCmd = new SqlCommand(addStockStr, connectSql);

            string addStockWith3DModelStr = "INSERT INTO Stocks(" +
                "StockName, Category, Brand, Price, StockStatus, Quantity, Image, Model3D, Texture" +
                ") VALUES(" +
                "@stock_name, @stock_category, @stock_brand, @stock_price, @stock_status, @stock_quantity, @stock_image, @stock_3dmodel, @stock_texture" +
                ")";
            addStockWith3DModelCmd = new SqlCommand(addStockWith3DModelStr, connectSql);

            //Remove Administrator linkbutton if privilege is not Owner and Admin
            if ((string)Session["privilege"] != "Owner" && (string)Session["privilege"] != "Admin")
            {
                linkAdminPage.Visible = false;
            }
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            string stock_name = txtStockName.Text;
            string stock_category = txtCategory.Text;
            string stock_brand = txtBrand.Text;
            float stock_price;
            string stock_status = ddlStockStatus.Text;
            int stock_quantity;
            string stock_image;
            string dataKey = "StockData";

            if (stock_name == "" || stock_category == "" || stock_brand == "" || stock_status == "")
            {
                Response.Write("<script>window.alert('Please Fill All the Form.')</script>");
                return;
            }

            try
            {
                stock_price = float.Parse(txtPrice.Text);
                stock_quantity = int.Parse(txtQuantity.Text);
            }
            catch (FormatException ex)
            {
                Response.Write("<script>window.alert('Please enter a valid numbers in Price and Quantity Field!')</script>");
                txtPrice.Text = "";
                txtQuantity.Text = "";
                return;
            }

            if (stock_price < 0 || stock_quantity < 0)
            {
                Response.Write("<script>window.alert('Negative value in Price and Quantity Field is not allow!')</script>");
                return;
            }

            if (fileUpload3DModel.HasFile)
            {
                if (fileUploadTexture3DModel.HasFile)
                {
                    addStockWith3DModelCmd.Parameters.Clear();
                    addStockWith3DModelCmd.Parameters.AddWithValue("stock_name", stock_name);
                    addStockWith3DModelCmd.Parameters.AddWithValue("stock_category", stock_category);
                    addStockWith3DModelCmd.Parameters.AddWithValue("stock_brand", stock_brand);
                    addStockWith3DModelCmd.Parameters.AddWithValue("stock_price", stock_price);
                    addStockWith3DModelCmd.Parameters.AddWithValue("stock_status", stock_status);
                    addStockWith3DModelCmd.Parameters.AddWithValue("stock_quantity", stock_quantity);

                    string stock_image_filename;
                    string stock_image_path;

                    if (fileUploadImage.HasFile)
                    {
                        stock_image_filename = fileUploadImage.FileName;
                        fileUploadImage.SaveAs(MapPath("~/Images/StockImages/" + fileUploadImage.FileName));
                        stock_image_path = "~/Images/StockImages/" + stock_image_filename;
                    }
                    else
                    {
                        stock_image_path = imgStock.ImageUrl;
                    }
                    addStockWith3DModelCmd.Parameters.AddWithValue("stock_image", stock_image_path);

                    string stock_3dmodel;
                    string stock_texture;

                    string stock_3dmodel_filename = fileUpload3DModel.FileName;
                    string stock_texture_filename = fileUploadTexture3DModel.FileName;

                    if (stock_3dmodel_filename.Substring(stock_3dmodel_filename.Length - 4) != ".glb")
                    {
                        Response.Write("<script>window.alert('Only .glb file type are acceptable for 3D Model!')</script>");
                        return;
                    }

                    fileUpload3DModel.SaveAs(MapPath("../../../Images/Models/" + fileUpload3DModel.FileName));
                    fileUploadTexture3DModel.SaveAs(MapPath("../../../Images/Models/" + fileUploadTexture3DModel.FileName));

                    stock_3dmodel = "../../../Images/Models/" + fileUpload3DModel.FileName;
                    stock_texture = "../../../Images/Models/" + fileUploadTexture3DModel.FileName;
                    addStockWith3DModelCmd.Parameters.AddWithValue("stock_3dmodel", stock_3dmodel);
                    addStockWith3DModelCmd.Parameters.AddWithValue("stock_texture", stock_texture);

                    int rowsAffected = addStockWith3DModelCmd.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        connectSql.Close();
                        Response.Write("<script>window.alert('Stock Added')</script>");
                        Response.Redirect("~/Forms/Privileges/Users/StockListPage.aspx");
                    }
                    else
                    {
                        Response.Write("<script>window.alert('Stock does not Add')</script>");
                    }
                }
                else
                {
                    Response.Write("<script>window.alert('Please Insert 3d Model Texture!')</script>");
                    return;
                }
            }
            else if (fileUploadTexture3DModel.HasFile)
            {
                Response.Write("<script>window.alert('Please Insert 3d Model!')</script>");
                return;
            }
            else
            {
                addStockCmd.Parameters.Clear();
                addStockCmd.Parameters.AddWithValue("stock_name", stock_name);
                addStockCmd.Parameters.AddWithValue("stock_category", stock_category);
                addStockCmd.Parameters.AddWithValue("stock_brand", stock_brand);
                addStockCmd.Parameters.AddWithValue("stock_price", stock_price);
                addStockCmd.Parameters.AddWithValue("stock_status", stock_status);
                addStockCmd.Parameters.AddWithValue("stock_quantity", stock_quantity);

                string stock_image_filename;
                string stock_image_path;

                if (fileUploadImage.HasFile)
                {
                    stock_image_filename = fileUploadImage.FileName;
                    fileUploadImage.SaveAs(MapPath("~/Images/StockImages/" + fileUploadImage.FileName));
                    stock_image_path = "~/Images/StockImages/" + stock_image_filename;
                }
                else
                {
                    stock_image_path = imgStock.ImageUrl;
                }

                addStockCmd.Parameters.AddWithValue("stock_image", stock_image_path);

                int rowsAffected = addStockCmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    connectSql.Close();
                    Response.Write("<script>window.alert('Stock Added')</script>");
                    Response.Redirect("~/Forms/Privileges/Users/StockListPage.aspx");
                }
                else
                {
                    Response.Write("<script>window.alert('Stock does not Add')</script>");
                }
            }
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            connectSql.Close();
            Response.Redirect("~/Forms/Privileges/Users/StockListPage.aspx");
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            FileUpload fileImg = new FileUpload();
            if (fileUploadImage.HasFile)
            {
                fileUploadImage.SaveAs(MapPath("~/Images/StockImages/" + fileUploadImage.FileName));
                imgStock.ImageUrl = "~/Images/StockImages/" + fileUploadImage.FileName;
            }
        }

        protected void linkLogout_Click(object sender, EventArgs e)
        {
            connectSql.Close();
            Session.Remove("user_name");
            Session.Remove("password");
            Session.Remove("privilege");
            Session.RemoveAll();
            Response.Redirect(Request.RawUrl);
        }

        protected void linkBack_Click(object sender, EventArgs e)
        {
            connectSql.Close();
            Response.Redirect("~/Forms/Dashboard" + Session["privilege"].ToString() + ".aspx");
        }

        protected void linkAdminPage_Click(object sender, EventArgs e)
        {
            connectSql.Close();
            Response.Redirect("~/Forms/Privileges/" + Session["privilege"].ToString() + "/AdministratorPage.aspx");
        }

        protected void txtQuantity_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (int.Parse(txtQuantity.Text) <= 0)
                {
                    ddlStockStatus.SelectedIndex = 2;
                }
                if (int.Parse(txtQuantity.Text) < 20 && int.Parse(txtQuantity.Text) > 0)
                {
                    ddlStockStatus.SelectedIndex = 1;
                }
                if (int.Parse(txtQuantity.Text) >= 20)
                {
                    ddlStockStatus.SelectedIndex = 0;
                }
            }
            catch (FormatException ex)
            {
                return;
            }
        }
    }
}