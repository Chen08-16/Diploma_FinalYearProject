﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;

namespace StockManagementSystem.Forms.Privileges.Users
{
    public partial class StockListPage : System.Web.UI.Page
    {
        private SqlConnection connectSql;
        private SqlCommand loadDataSourceCmd;
        private SqlCommand searchBySelectionCmd;
        private string dataKey = "data";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user_name"] != null && Session["password"] != null)
            {
                Response.ClearHeaders();
                Response.AddHeader("Cache-Control", "no-cache, no-store, max-age=0, must-revalidate");
                Response.AddHeader("Pragma", "no-cache");

                //Remove Administrator linkbutton if privilege is not Owner and Admin
                if ((string)Session["privilege"] != "Owner" && (string)Session["privilege"] != "Admin")
                {
                    linkAdminPage.Visible = false;
                }

                string connectStr = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|StockDatabase.mdf";
                connectSql = new SqlConnection(connectStr);

                try
                {
                    connectSql.Open();
                }
                catch (SqlException ex)
                {
                    Response.Write("<script>window.alert('SQL connection Failed!')</script>");
                }
            }
            else
            {
                Response.Write("<script>window.alert('Login Failed!')</script>");
                Response.Redirect("~/Forms/Login.aspx");
            }
        }

        protected void btnAddStock_Click(object sender, EventArgs e)
        {
            connectSql.Close();
            Response.Redirect("~/Forms/Privileges/Users/AddStockPage.aspx");
        }

        protected void onRowDataBound(object sender, System.Web.UI.WebControls.GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Attributes["onclick"] = Page.ClientScript.GetPostBackClientHyperlink(gridViewStocks, "Select$" + e.Row.RowIndex);
                e.Row.Attributes["style"] = "cursor:pointer";
            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Session["stock_id"] = gridViewStocks.SelectedRow.Cells[0].Text; //get stock id into next page
            Response.Redirect("~/Forms/Privileges/Users/StockDetailsPage.aspx");
        }

        protected void btnSelect_Click(object sender, EventArgs e)
        {
            connectSql.Close();
            Response.Redirect("~/Forms/Privileges/Users/DeleteStockListPage.aspx");
        }

        protected void linkBack_Click(object sender, EventArgs e)
        {
            connectSql.Close();
            string user_privilege = (string)Session["privilege"];
            //Response.Write("<script>window.alert('" + user_privilege + "')</script>");
            Response.Redirect("~/Forms/Dashboard" + user_privilege + ".aspx");
        }

        protected void linkLogout_Click(object sender, EventArgs e)
        {
            connectSql.Close();
            Session.Remove("user_name");
            Session.Remove("password");
            Session.Remove("privilege");
            Session.RemoveAll();
            Response.Redirect(Request.RawUrl);
        }

        protected void linkAdminPage_Click(object sender, EventArgs e)
        {
            connectSql.Close();
            Response.Redirect("~/Forms/Privileges/" + Session["privilege"].ToString() + "/AdministratorPage.aspx");
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            searchDatabase();
        }

        private void searchDatabase()
        {
            if (txtSearch.Text == "")
            {
                loadDatabase();
                lblSearchError.Text = "";
                return;
            }

            string commandStr;

            switch (ddlSearch.SelectedIndex)
            {
                case 0:
                    commandStr = "SELECT * FROM Stocks WHERE StockId = @stock_search ORDER BY StockId";
                    if (!(int.TryParse(txtSearch.Text, out int output)))
                    {
                        lblSearchError.Text = "Only Numberic is acceptable";
                        return;
                    }
                    else
                    {
                        lblSearchError.Text = "";
                    }
                    break;

                case 1:
                    commandStr = "SELECT * FROM Stocks WHERE StockName LIKE @stock_search + '%' ORDER BY StockId";
                    break;

                case 2:
                    commandStr = "SELECT * FROM Stocks WHERE Category LIKE @stock_search + '%' ORDER BY StockId";
                    break;

                case 3:
                    commandStr = "SELECT * FROM Stocks WHERE Brand LIKE @stock_search + '%' ORDER BY StockId";
                    break;

                case 4:
                    commandStr = "SELECT * FROM Stocks WHERE Price = @stock_search ORDER BY StockId";
                    if (!(float.TryParse(txtSearch.Text, out float outputFloat)))
                    {
                        lblSearchError.Text = "Only Numberic is acceptable";
                        return;
                    }
                    else
                    {
                        lblSearchError.Text = "";
                    }
                    break;

                case 5:
                    commandStr = "SELECT * FROM Stocks WHERE StockStatus LIKE @stock_search + '%' ORDER BY StockId";
                    break;

                case 6:
                    commandStr = "SELECT * FROM Stocks WHERE Quantity = @stock_search ORDER BY StockId";
                    if (!(int.TryParse(txtSearch.Text, out output)))
                    {
                        lblSearchError.Text = "Only Numberic is acceptable";
                        return;
                    }
                    else
                    {
                        lblSearchError.Text = "";
                    }
                    break;

                default:
                    commandStr = "SELECT * FROM Stocks WHERE StockId = @stock_search ORDER BY StockId";
                    break;
            }

            searchBySelectionCmd = new SqlCommand(commandStr, connectSql);

            searchBySelectionCmd.Parameters.Clear();
            searchBySelectionCmd.Parameters.AddWithValue("stock_search", txtSearch.Text);

            SqlDataAdapter adapter = new SqlDataAdapter(searchBySelectionCmd);
            DataSet dataSet = new DataSet();
            adapter.Fill(dataSet, dataKey);

            DataTable dataTable = dataSet.Tables[dataKey];

                gridViewStocks.DataSourceID = null;
                gridViewStocks.DataSource = dataTable;
                gridViewStocks.DataBind();
        }

        private void loadDatabase()
        {
            string loadDataSourceStr = "SELECT * FROM Stocks";
            loadDataSourceCmd = new SqlCommand(loadDataSourceStr, connectSql);

            SqlDataAdapter adapter = new SqlDataAdapter(loadDataSourceCmd);
            DataSet dataSet = new DataSet();
            adapter.Fill(dataSet, dataKey);

            DataTable dataTable = dataSet.Tables[dataKey];

            if (dataTable.Rows.Count == 0)
            {
                return;
            }
            else
            {
                gridViewStocks.DataSourceID = null;
                gridViewStocks.DataSource = dataTable;
                gridViewStocks.DataBind();
            }
        }
    }
}