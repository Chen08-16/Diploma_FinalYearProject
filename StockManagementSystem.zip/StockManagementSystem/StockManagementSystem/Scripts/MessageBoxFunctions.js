﻿//Messagebox for general
function askingForUpdateItem() {
    return confirm("Are you sure want to update selected item?");
}
function askingForDeleteItem() {
    return confirm("Are you sure want to delete selected item?");
}

//Messagebox for update item
function askingForUpdateItemStock() {
    return confirm("Are you sure want to update this stock?");
}
function askingForUpdateItemProfile() {
    return confirm("Are you sure want to update this profile?");
}

//Prompt Messagebox
function MsgBox(message) {
    alert(message);
}
